// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyCunE8vtIk9k_k83ONEHXfcXsu7efCjM_U",
    authDomain: "massageapp-5c298.firebaseapp.com",
    projectId: "massageapp-5c298",
    storageBucket: "massageapp-5c298.appspot.com",
    messagingSenderId: "574158626321",
    appId: "1:574158626321:web:93a2a3254e17ee9aad5bb0",
    measurementId: "G-N72860PN9L"
  }
  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
